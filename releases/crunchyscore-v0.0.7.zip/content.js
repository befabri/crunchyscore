var Provider = /* @__PURE__ */ ((Provider2) => {
  Provider2[Provider2["MyAnimeList"] = 1] = "MyAnimeList";
  Provider2[Provider2["AniList"] = 2] = "AniList";
  return Provider2;
})(Provider || {});
const defaultConfig = {
  provider: 1,
  tab1: {
    color: "#f47521",
    layout: "layout4",
    text: "Score",
    order: "order1",
    decimal: "decimal1"
  },
  tab2: {
    color: "#a0a0a0",
    layout: "layout3",
    text: "| Score",
    decimal: "decimal2"
  }
};
let config = defaultConfig;
function restore() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["provider", "tab1", "tab2"], function(data) {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(data);
      }
    });
  });
}
async function updateConfig() {
  try {
    const data = await restore();
    config.provider = data.provider !== void 0 ? data.provider : defaultConfig.provider;
    config.tab1 = data.tab1 !== void 0 ? data.tab1 : defaultConfig.tab1;
    config.tab2 = data.tab2 !== void 0 ? data.tab2 : defaultConfig.tab2;
  } catch (error) {
    console.error(error);
  }
}
function isHTMLElement(element) {
  return element instanceof HTMLElement;
}
function roundScore(score, decimalConfig) {
  switch (decimalConfig) {
    case "decimal1":
      return Math.floor(score * 100) / 100;
    case "decimal2":
      return Math.floor(score * 10) / 10;
    case "decimal3":
      return Math.floor(score);
    default:
      return score;
  }
}
function extractIdFromUrl(url) {
  if (!url) {
    return null;
  }
  const urlObj = new URL(url, window.location.origin);
  const pathParts = urlObj.pathname.split("/");
  let idIndex = pathParts[1] === "series" ? 2 : 3;
  return pathParts[idIndex];
}
function findAnimeById(anime, animes) {
  return animes.find((obj) => obj.id === anime.id);
}
function getAnimeFromCurrentUrl() {
  const url = location.href;
  const id = extractIdFromUrl(url);
  if (!id) {
    return null;
  }
  return { id, seasonTags: null };
}
function isDetailPage(url) {
  if (!url) {
    return false;
  }
  const urlObj = new URL(url);
  const pathParts = urlObj.pathname.split("/");
  return pathParts[1] === "series" || pathParts[2] === "series";
}
function isSimulcastPage(url) {
  const segments = url.split("/");
  return segments[segments.length - 2] === "seasons";
}
function isVideoPage() {
  if (!document.querySelector(".erc-browse-collection.state-loading")) {
    return !!document.querySelector(".browse-card:not(.browse-card-placeholder--6UpIg)") || !!document.querySelector("#content > div > div.app-body-wrapper > div > div > div.erc-genres-header");
  }
  return false;
}
function returnHref(children) {
  return Array.from(children).map((child) => child.href).sort().join("|");
}
var ScoreType = /* @__PURE__ */ ((ScoreType2) => {
  ScoreType2["CARD"] = "card";
  ScoreType2["DETAIL"] = "detail";
  return ScoreType2;
})(ScoreType || {});
function insertScore(spanElement, score, type) {
  if (type !== "card" && type !== "detail") {
    return;
  }
  const classSelector = type === "card" ? ".score-card" : ".score-hero";
  let tabConfig;
  switch (type) {
    case "card":
      tabConfig = config.tab1;
      break;
    case "detail":
      tabConfig = config.tab2;
      break;
  }
  if (spanElement.querySelector(classSelector)) {
    return;
  }
  const scoreElement = createScoreElement(score, type, tabConfig, config.provider === Provider.AniList);
  if (type === "card") {
    insertToLayoutCard(scoreElement, spanElement, tabConfig.layout);
  } else if (type === "detail") {
    insertToLayoutHero(scoreElement, spanElement, tabConfig.layout);
  }
}
function updateScore(element, request, type, parentElem) {
  if (type !== "card" && type !== "detail")
    return;
  const tab = type === "card" ? request.tab1 : request.tab2;
  updateElementScore(".score-card", element, tab, type);
  if (parentElem)
    updateElementScore(".score-hero", parentElem, tab, type, parentElem);
}
function updateElementScore(selector, context, tab, type, parentElem) {
  const scoreElement = context.querySelector(selector);
  if (!isHTMLElement(scoreElement))
    return;
  scoreElement.style.color = tab.color;
  const numberScoreAttr = scoreElement.getAttribute("data-numberscore");
  if (numberScoreAttr === null)
    return;
  const numberScore = parseFloat(numberScoreAttr);
  const roundedScore = roundScore(numberScore, tab.decimal);
  scoreElement.setAttribute("data-textscore", tab.text);
  scoreElement.setAttribute("data-numberscore", roundedScore.toString());
  const isAnilist = config.provider === Provider.AniList;
  scoreElement.textContent = ` ${tab.text} ${roundedScore}${isAnilist ? "%" : ""}`;
  if (type === "card") {
    insertToLayoutCard(scoreElement, context, tab.layout);
  } else if (type === "detail" && parentElem) {
    insertToLayoutHero(scoreElement, parentElem, tab.layout);
  }
}
function createScoreElement(score, type, tabConfig, isAnilist) {
  const scoreElement = document.createElement("span");
  const scoreNumber = roundScore(score, tabConfig.decimal);
  scoreElement.textContent = ` ${tabConfig.text} ${scoreNumber}${isAnilist ? "%" : ""}`;
  scoreElement.style.color = tabConfig.color;
  scoreElement.classList.add(type === "card" ? "score-card" : "score-hero");
  scoreElement.setAttribute("data-textscore", tabConfig.text);
  scoreElement.setAttribute("data-numberscore", scoreNumber.toString());
  return scoreElement;
}
function insertToLayoutCard(score, targetElement, layout) {
  var _a, _b;
  const h4Element = targetElement.querySelector("h4");
  switch (layout) {
    case "layout1":
      h4Element == null ? void 0 : h4Element.appendChild(score);
      break;
    case "layout2":
      (_a = h4Element == null ? void 0 : h4Element.parentNode) == null ? void 0 : _a.insertBefore(score, h4Element.nextElementSibling);
      break;
    case "layout3":
      (_b = targetElement.querySelector('div[data-t="meta-tags"]')) == null ? void 0 : _b.appendChild(score);
      break;
    case "layout4":
      targetElement.appendChild(score);
      break;
  }
}
function insertToLayoutHero(score, targetElement, layout) {
  var _a, _b;
  const h1Element = targetElement.querySelector("h1");
  const tag = document.querySelector("div.erc-series-tags.tags");
  switch (layout) {
    case "layout1":
      h1Element == null ? void 0 : h1Element.appendChild(score);
      break;
    case "layout2":
      (_a = h1Element == null ? void 0 : h1Element.parentNode) == null ? void 0 : _a.insertBefore(score, h1Element.nextElementSibling);
      break;
    case "layout3":
      (_b = tag == null ? void 0 : tag.querySelector('div[data-t="meta-tags"]')) == null ? void 0 : _b.appendChild(score);
      break;
  }
}
const TIMESTAMP_REFRESH_CACHE = "lastRefreshTime";
const NOT_FOUND_CACHE = "notFoundCache";
async function refreshNotFoundCache() {
  const notFoundCache = getNotFoundCache();
  const urls = Object.values(notFoundCache);
  await fetchAndSaveAnimeScores(urls);
  localStorage.setItem(TIMESTAMP_REFRESH_CACHE, Date.now().toString());
}
function getNotFoundCache() {
  const notFoundCache = localStorage.getItem(NOT_FOUND_CACHE);
  if (notFoundCache) {
    return JSON.parse(notFoundCache);
  } else {
    return {};
  }
}
function getTimestampNotFoundCache() {
  const storedValue = localStorage.getItem(TIMESTAMP_REFRESH_CACHE) ?? "";
  return parseInt(storedValue, 10) || 0;
}
function setNotFoundCache(cacheData) {
  localStorage.setItem(NOT_FOUND_CACHE, JSON.stringify(cacheData));
}
function updateNotFoundCache(fetchedAnime) {
  let cacheData = getNotFoundCache();
  fetchedAnime.forEach((anime) => {
    if (anime.id && anime.score && anime.score > 0) {
      delete cacheData[anime.id];
    } else {
      cacheData[anime.id] = anime;
    }
  });
  setNotFoundCache(cacheData);
}
const BASE_URL = "https://api.crunchyscore.app/api/crunchyroll/score";
const BLACKLIST_IDS = [
  "GY1XXXPQY",
  "G6EXH7VKM",
  "G6190VXEY",
  "GR19JEWQ6",
  "GREX5KEXY",
  "GR24X90E6",
  "GR19MD406",
  "G6NQK7Z36",
  "G3KHEV0Q1",
  "G6JQ1Q8WR",
  "G24H1NWV7",
  "G6WE4W0N6",
  "GDKHZENQ0",
  "GYWE2G8JY",
  "G6JQ14Q2R",
  "GR1XP20GR",
  "G65PV1NE6",
  "G24H1N898",
  "G8DHV7D17",
  "GRVNE7N4Y",
  "GZJH3DXQD",
  "GR09G930R",
  "GRQW4DPPR",
  "G69PV5EVY",
  "GRWEQ4ZNR",
  "G6NQV80X6",
  "GYP5E27KY",
  "G6X03JPMY",
  "GEXH3WGNX",
  "GY49P88ER",
  "GYK5X214R",
  "GYVD2XZXY"
];
function isBlacklisted(animeId) {
  return BLACKLIST_IDS.includes(animeId);
}
async function fetchAnimeScores(crunchyrollList) {
  try {
    const response = await fetch(BASE_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(crunchyrollList)
    });
    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    return null;
  }
}
async function fetchAndSaveAnimeScores(animes) {
  if (Object.keys(animes).length === 0) {
    return null;
  }
  const crunchyrollList = prepareObjectFetch(animes);
  const animeFetch = await fetchAnimeScores(crunchyrollList);
  if (animeFetch) {
    updateNotFoundCache(animeFetch);
  }
  return animeFetch;
}
function prepareObjectFetch(animes) {
  const list = [];
  for (const anime of Object.values(animes)) {
    if (anime.id && !isBlacklisted(anime.id)) {
      list.push({ id: anime.id, seasonTags: null });
    }
  }
  return list;
}
const TIMESTAMP_REFRESH_ANIME_CACHE = "lastRefreshTimeAnime";
async function saveData(animeFetch) {
  return new Promise((resolve) => {
    chrome.storage.local.get(["datas"], function(result) {
      let animeData = result.datas || [];
      animeFetch.forEach((anime) => {
        if (anime && typeof anime.score === "number" && typeof anime.anilist_score === "number") {
          const existingAnimeIndex = animeData.findIndex((a) => a && a.id === anime.id);
          if (existingAnimeIndex !== -1) {
            if (anime.score !== 0) {
              animeData[existingAnimeIndex] = anime;
            }
          } else if (anime.score) {
            animeData.push(anime);
          }
        }
      });
      chrome.storage.local.set({ datas: animeData }, function() {
        resolve();
      });
    });
  });
}
async function getStorageAnimeData() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["datas"], (result) => {
      const animes = result.datas || [];
      resolve(animes);
    });
  });
}
async function refreshAnime() {
  const animesScore = await getStorageAnimeData();
  const animes = animesScore.map((animeScore) => {
    return {
      id: animeScore.id
    };
  });
  const animeFetch = await fetchAndSaveAnimeScores(animes);
  if (animeFetch) {
    await saveData(animeFetch.filter((anime) => anime.score !== 0));
  }
  localStorage.setItem(TIMESTAMP_REFRESH_ANIME_CACHE, Date.now().toString());
}
function getTimestampAnimeRefresh() {
  const storedValue = localStorage.getItem(TIMESTAMP_REFRESH_ANIME_CACHE) ?? "";
  return parseInt(storedValue, 10) || 0;
}
const REFRESH_DELAY = 60 * 1e3 * 24 * 3;
const REFRESH_DELAY_CACHE_NOT_FOUND = 60 * 1e3 * 2;
let pastURL = location.href;
let parentContainer;
let parentClonedContainer;
async function handleCardPage() {
  if (isDetailPage(location.href)) {
    return;
  }
  const lastRefreshTimeNotFound = getTimestampNotFoundCache();
  if (Date.now() - lastRefreshTimeNotFound >= REFRESH_DELAY_CACHE_NOT_FOUND) {
    await refreshNotFoundCache();
  }
  const lastRefreshTime = getTimestampAnimeRefresh();
  if (Date.now() - lastRefreshTime >= REFRESH_DELAY) {
    await refreshAnime();
  }
  let animesStorage = await getStorageAnimeData();
  const animeNotFound = await insertScoreController(animesStorage);
  if (!animeNotFound) {
    return;
  }
  const notFoundCache = getNotFoundCache();
  const animes = animeNotFound.filter((anime) => !notFoundCache[anime.id]);
  if (animes.length > 0) {
    const animeFetch = await fetchAndSaveAnimeScores(animes);
    if (animeFetch) {
      await saveData(animeFetch.filter((anime) => anime.score !== 0));
      animesStorage = await getStorageAnimeData();
      await insertScoreController(animesStorage);
    }
  }
}
async function insertScoreController(animes) {
  var _a, _b;
  if (isSimulcastPage(location.href) && pastURL !== location.href && parentContainer && parentClonedContainer) {
    const parentHref = returnHref(parentContainer.children);
    if (!parentHref || parentHref === returnHref(parentClonedContainer.children)) {
      location.reload();
      return null;
    }
    if (parentClonedContainer.childElementCount !== 0 && parentContainer.childElementCount !== 0) {
      (_a = parentClonedContainer.parentNode) == null ? void 0 : _a.replaceChild(parentContainer, parentClonedContainer);
    }
  }
  const cards = Array.from(getCardsFromVideoPage());
  const notFound = cards.reduce((acc, card) => {
    const cardElement = card;
    const data = getDataFromCard(cardElement, animes);
    if (data) {
      if (config.provider === Provider.AniList) {
        insertScore(cardElement, data.anilist_score, ScoreType.CARD);
      } else {
        insertScore(cardElement, data.score, ScoreType.CARD);
      }
    } else {
      const notFoundAnime = getSearchFromCard(cardElement);
      if (notFoundAnime && notFoundAnime.id) {
        acc.push(notFoundAnime);
      }
    }
    return acc;
  }, []);
  if (!isSimulcastPage(location.href) || config.tab1.order === "order1") {
    pastURL = location.href;
    return notFound;
  }
  const sortChildren = (node) => {
    const sorted = Array.from(node.children).map((card) => {
      const scoreElement = card.querySelector(".score-card");
      return {
        node: card,
        score: scoreElement ? parseFloat(scoreElement.getAttribute("data-numberscore") || "0") : 0
      };
    }).sort(
      (a, b) => config.tab1.order === "order2" ? a.score - b.score : b.score - a.score
    );
    sorted.forEach(({ node: childNode }) => node.appendChild(childNode));
  };
  parentContainer = document.querySelector(".erc-browse-cards-collection");
  parentClonedContainer = parentContainer ? parentContainer.cloneNode(true) : null;
  const unwantedChildren = parentClonedContainer == null ? void 0 : parentClonedContainer.querySelectorAll(
    ".browse-card-placeholder--6UpIg.browse-card, .browse-card-placeholder--6UpIg.browse-card.hidden-mobile"
  );
  unwantedChildren == null ? void 0 : unwantedChildren.forEach((child) => {
    var _a2;
    return (_a2 = child.parentNode) == null ? void 0 : _a2.removeChild(child);
  });
  if (parentClonedContainer) {
    sortChildren(parentClonedContainer);
    if (parentClonedContainer.childElementCount !== 0 && parentContainer) {
      (_b = parentContainer.parentNode) == null ? void 0 : _b.replaceChild(parentClonedContainer, parentContainer);
    }
  }
  pastURL = location.href;
  return notFound;
}
function getDataFromCard(card, animes) {
  const anime = getSearchFromCard(card);
  if (!anime) {
    return;
  }
  return findAnimeById(anime, animes);
}
function getSearchFromCard(card) {
  const anchorElement = card.querySelector('a[tabindex="0"]');
  if (!anchorElement) {
    return;
  }
  const href = anchorElement.getAttribute("href");
  if (!href) {
    return;
  }
  const id = extractIdFromUrl(href);
  if (!id) {
    return;
  }
  return { id, seasonTags: null };
}
function getCardsFromVideoPage() {
  return document.querySelectorAll('[data-t="series-card "]') || document.querySelectorAll(".browse-card--esJdT");
}
async function handleDetailPage() {
  const targetElem = document.querySelector("div.hero-heading-line");
  if (targetElem && !document.querySelector(".score-hero")) {
    const animesStorage = await getStorageAnimeData();
    const anime = getAnimeFromCurrentUrl();
    if (anime !== null) {
      const animeScore = findAnimeById(anime, animesStorage);
      if (animeScore) {
        if (config.provider === Provider.AniList) {
          insertScore(targetElem, animeScore.anilist_score, ScoreType.DETAIL);
        } else {
          insertScore(targetElem, animeScore.score, ScoreType.DETAIL);
        }
      } else {
        if (!isBlacklisted(anime.id)) {
          const animeFetch = await fetchAnimeScores([anime]);
          if (animeFetch && animeFetch.length > 0) {
            insertScore(targetElem, animeFetch[0].score, ScoreType.DETAIL);
            await saveData(animeFetch);
          }
        }
      }
    }
  }
}
updateConfig();
let check = false;
chrome.runtime.onMessage.addListener(function(request) {
  try {
    if (request.type != "popupSaved" && request.type != "forceRefreshCache" && request.type != "changeProvider") {
      check = false;
    }
    if (request.type === "forceRefreshCache") {
      (async () => {
        await refreshNotFoundCache();
      })();
    }
    if (request.type === "changeProvider") {
      (async () => {
        await updateConfig();
      })();
      location.reload();
    }
    if (request.type === "popupSaved") {
      const cards = document.querySelectorAll('[data-t="series-card "]');
      cards.forEach((card) => {
        if (isHTMLElement(card)) {
          updateScore(card, request, ScoreType.CARD);
        }
      });
      let elements = document.getElementsByClassName("score-hero");
      const parentElem = document.querySelector(".erc-series-hero");
      for (let i = 0; i < elements.length; i++) {
        let element = elements[i];
        if (isHTMLElement(element)) {
          updateScore(element, request, ScoreType.DETAIL, parentElem);
        }
      }
      (async () => {
        await updateConfig();
      })();
      if (request.tab1.order != config.tab1.order) {
        if (request.tab1.order === "order1") {
          location.reload();
        } else {
          (async () => {
            const data = await getStorageAnimeData();
            await insertScoreController(data);
          })();
        }
      }
      if (request.tab1.decimal != config.tab1.decimal || request.tab2.decimal != config.tab2.decimal) {
        location.reload();
      }
    }
    setInterval(function() {
      if (check === false) {
        if (isVideoPage() && Array.from(getCardsFromVideoPage()).length > 0) {
          updateConfig();
          handleCardPage();
          check = true;
        }
      }
      if (check === false && document.querySelector(".star-rating__reviews-link--lkG9- span")) {
        updateConfig();
        handleDetailPage();
        check = true;
      }
    }, 800);
  } catch (error) {
    console.error("Error ");
  }
});
let throttleTimeout = null;
window.addEventListener("scroll", () => {
  if (throttleTimeout === null) {
    throttleTimeout = setTimeout(() => {
      if (isVideoPage() && !isSimulcastPage(location.href)) {
        updateConfig();
        handleCardPage();
      }
      throttleTimeout = null;
    }, 800);
  }
});
