const PROVIDER_IDS = {
  MYANIMELIST: "provider-myanimelist",
  ANILIST: "provider-anilist"
};
document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll("[data-i18n]");
  elements.forEach((element) => {
    const htmlElement = element;
    const i18nKey = htmlElement.dataset.i18n;
    if (i18nKey) {
      const message = chrome.i18n.getMessage(i18nKey);
      htmlElement.textContent = message;
    }
  });
  const tabTitle = document.getElementById("tabTitle");
  const btnCards = document.getElementById("btnCards");
  const btnDetail = document.getElementById("btnDetail");
  const btnWatch = document.getElementById("btnWatch");
  const btnBackFromCards = document.getElementById("btnBackFromCards");
  const btnBackFromDetail = document.getElementById("btnBackFromDetail");
  const btnBackFromWatch = document.getElementById("btnBackFromWatch");
  const btnForceRefreshCache = document.getElementById("btnCache");
  const main = document.getElementById("main");
  const cardsSettings = document.getElementById("cardsSettings");
  const detailSettings = document.getElementById("detailSettings");
  const watchSettings = document.getElementById("watchSettings");
  const colorChoice1 = document.getElementById("colorChoice1");
  const colorChoice2 = document.getElementById("colorChoice2");
  const colorChoice3 = document.getElementById("colorChoice3");
  const colorText1 = document.getElementById("colorText1");
  const colorText2 = document.getElementById("colorText2");
  const colorText3 = document.getElementById("colorText3");
  const spinner = document.getElementById("spinner");
  const successIcon = document.getElementById("successIcon");
  const buttonTabProviderMal = document.getElementById("provider-myanimelist");
  const buttonTabProviderAni = document.getElementById("provider-anilist");
  const buttonTabsProvider = [buttonTabProviderMal, buttonTabProviderAni];
  function toggleVisibility(showElement) {
    const elements2 = [main, cardsSettings, detailSettings, watchSettings];
    elements2.forEach((el) => {
      el.classList.add("hidden");
      el.classList.remove("flex");
    });
    if (showElement) {
      showElement.classList.remove("hidden");
      showElement.classList.add("flex");
    }
  }
  function showCardsSettings() {
    toggleVisibility(cardsSettings);
    tabTitle.innerText = chrome.i18n.getMessage("cardsPageButtonText");
  }
  function showDetailSettings() {
    toggleVisibility(detailSettings);
    tabTitle.innerText = chrome.i18n.getMessage("detailPageButtonText");
  }
  function showWatchSettings() {
    toggleVisibility(watchSettings);
    tabTitle.innerText = chrome.i18n.getMessage("watchPageButtonText");
  }
  function goBack() {
    toggleVisibility(main);
    tabTitle.innerText = chrome.i18n.getMessage("title");
  }
  function forceRefreshCache() {
    btnForceRefreshCache.disabled = true;
    spinner.style.display = "";
    successIcon.style.display = "none";
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0].id !== void 0) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: "forceRefreshCache"
        });
      }
    });
    setTimeout(() => {
      spinner.style.display = "none";
      successIcon.style.display = "";
      setTimeout(() => {
        btnForceRefreshCache.disabled = false;
        successIcon.style.display = "none";
      }, 2e3);
    }, 1600);
  }
  btnForceRefreshCache.addEventListener("click", forceRefreshCache);
  btnCards.addEventListener("click", showCardsSettings);
  btnDetail.addEventListener("click", showDetailSettings);
  btnWatch.addEventListener("click", showWatchSettings);
  btnBackFromCards.addEventListener("click", goBack);
  btnBackFromDetail.addEventListener("click", goBack);
  btnBackFromWatch.addEventListener("click", goBack);
  buttonTabsProvider.forEach((providerButton) => {
    providerButton.addEventListener("click", () => {
      const providerId = providerButton.id === PROVIDER_IDS.MYANIMELIST ? 1 : 2;
      setProviderVisualState(providerButton.id);
      changeProvider(providerId);
    });
  });
  function changeProvider(providerId) {
    chrome.storage.local.set({ provider: providerId }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        var _a;
        const tabId = (_a = tabs[0]) == null ? void 0 : _a.id;
        if (tabId !== void 0) {
          chrome.tabs.sendMessage(tabId, { type: "changeProvider" });
        }
      });
    });
  }
  chrome.storage.local.get(["provider"], (result) => {
    const initialProviderId = result.provider === 2 ? PROVIDER_IDS.ANILIST : PROVIDER_IDS.MYANIMELIST;
    setProviderVisualState(initialProviderId);
  });
  function setProviderVisualState(activeProviderId) {
    buttonTabsProvider.forEach((button) => {
      const isSelected = button.id === activeProviderId;
      button.setAttribute("aria-selected", String(isSelected));
      button.classList.toggle("bg-white", isSelected);
      button.classList.toggle("bg-gray-200", !isSelected);
    });
  }
  [colorChoice1, colorChoice2, colorChoice3].forEach((colorChoice, index) => {
    colorChoice.addEventListener("input", function() {
      document.getElementById(`colorText${index + 1}`).value = this.value;
    });
  });
  [colorText1, colorText2, colorText3].forEach((colorText, index) => {
    colorText.addEventListener("input", function() {
      const colorCode = this.value;
      if (/^#[0-9A-F]{6}$/i.test(colorCode)) {
        document.getElementById(`colorChoice${index + 1}`).value = colorCode;
      }
    });
  });
  document.querySelectorAll(".saveButton").forEach((element) => {
    const button = element;
    button.addEventListener("click", function() {
      this.disabled = true;
      const colorChoice = document.getElementById("colorChoice1").value;
      const layoutChoice = document.getElementById("layoutChoice1").value;
      const textChoice = document.getElementById("textChoice1").value;
      const decimalChoice = document.getElementById("decimalChoice1").value;
      const orderChoice = document.getElementById("orderChoice1").value;
      const colorChoiceTab2 = document.getElementById("colorChoice2").value;
      const layoutChoiceTab2 = document.getElementById("layoutChoice2").value;
      const textChoiceTab2 = document.getElementById("textChoice2").value;
      const decimalChoiceTab2 = document.getElementById("decimalChoice2").value;
      const colorChoiceTab3 = document.getElementById("colorChoice3").value;
      const layoutChoiceTab3 = document.getElementById("layoutChoice3").value;
      const textChoiceTab3 = document.getElementById("textChoice3").value;
      const decimalChoiceTab3 = document.getElementById("decimalChoice3").value;
      const tab1 = {
        color: colorChoice,
        layout: layoutChoice,
        text: textChoice,
        order: orderChoice,
        decimal: decimalChoice
      };
      const tab2 = {
        color: colorChoiceTab2,
        layout: layoutChoiceTab2,
        text: textChoiceTab2,
        decimal: decimalChoiceTab2
      };
      const tab3 = {
        color: colorChoiceTab3,
        layout: layoutChoiceTab3,
        text: textChoiceTab3,
        decimal: decimalChoiceTab3
      };
      chrome.storage.local.set({ tab1, tab2, tab3 }, () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0].id !== void 0) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: "popupSaved",
              tab1,
              tab2,
              tab3
            });
          }
        });
      });
      setTimeout(() => {
        this.disabled = false;
      }, 800);
    });
  });
  ["tab1", "tab2", "tab3"].forEach((tab, index) => {
    chrome.storage.local.get([tab], (data) => {
      let tabData = data[tab];
      if (tabData) {
        document.getElementById(`colorChoice${index + 1}`).value = tabData.color;
        document.getElementById(`colorText${index + 1}`).value = tabData.color;
        document.getElementById(`layoutChoice${index + 1}`).value = tabData.layout;
        document.getElementById(`textChoice${index + 1}`).value = tabData.text;
        document.getElementById(`decimalChoice${index + 1}`).value = tabData.decimal;
        if (tabData.hasOwnProperty("order")) {
          document.getElementById(`orderChoice${index + 1}`).value = tabData.order;
        }
      }
    });
  });
});
